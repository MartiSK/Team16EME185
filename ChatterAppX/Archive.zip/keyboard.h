//
//  keyboard.h
//  ChatterAppX
//
//  Created by Marti Sarigul-Klijn on 4/8/15.
//  Copyright (c) 2015 Team16. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface keyboard : NSObject

@property (strong, nonatomic) id keyboard;

-(void) keyboardWasShown;


@end
