//
//  keyboard.m
//  ChatterAppX
//
//  Created by Marti Sarigul-Klijn on 4/8/15.
//  Copyright (c) 2015 Team16. All rights reserved.
//

#import "keyboard.h"

@interface keyboard ()

- (void)keyboardWasShown:(NSNotification*)aNotification; {
    NSDictionary* info = [aNotification userInfo];
    CGSize kbSize = [[info objectForKey:UIKeyboardFrameBeginUserInfoKey] CGRectValue].size;
    CGRect bkgndRect = activeField.superview.frame;
    bkgndRect.size.height += kbSize.height;
    [activeField.superview setFrame:bkgndRect];
    [scrollView setContentOffset:CGPointMake(0.0, activeField.frame.origin.y-kbSize.height) animated:YES];
}
@end

@implementation keyboard

/* - (void)viewDidLoad {
    [super viewDidLoad];
    // Do view setup here.
}

 */
 
/* @interface keyboard ()
 func keyboardWasShown(notification: NSNotifcation) {
 var info = notication.userInfo!
 var keyboardFrame: CGRect = (info[UIKeboardFrameEndUserInfoKey] as NSValue).CGRectValue
 
 UIView.animateWithDuration(0.1, animations: { () -> Void in
 self.bottomContraint.constant = keboardFrame.size.height; +20
 })
 }
 */


/* #define kOFFSET_FOR_KEYBOARD 80.0
 
 - (void)keyboardWillShow; (
 // Animate the current view out of the way
 if (self.view.frame.origin.y >= 0)
 {
 [self setViewMovedUp:YES];
 }
 else if (self.view.frame.origin.y < 0)
 {
 [self setViewMovedUp:NO];
 }
 }
 
 -(void)keyboardWillHide {
 if (self.view.frame.origin.y >= 0)
 {
 [self setViewMovedUp:YES];
 }
 else if (self.view.frame.origin.y < 0)
 {
 [self setViewMovedUp:NO];
 }
 }
 
 -(void)textFieldDidBeginEditing:(UITextField *)sender
 {
 if ([sender isEqual:mailTf])
 {
 //move the main view, so that the keyboard does not hide it.
 if  (self.view.frame.origin.y >= 0)
 {
 [self setViewMovedUp:YES];
 }
 }
 }
 
 //method to move the view up/down whenever the keyboard is shown/dismissed
 -(void)setViewMovedUp:(BOOL)movedUp
 {
 [UIView beginAnimations:nil context:NULL];
 [UIView setAnimationDuration:0.3]; // if you want to slide up the view
 
 CGRect rect = self.view.frame;
 if (movedUp)
 {
 // 1. move the view's origin up so that the text field that will be hidden come above the keyboard
 // 2. increase the size of the view so that the area behind the keyboard is covered up.
 rect.origin.y -= kOFFSET_FOR_KEYBOARD;
 rect.size.height += kOFFSET_FOR_KEYBOARD;
 }
 else
 {
 // revert back to the normal state.
 rect.origin.y += kOFFSET_FOR_KEYBOARD;
 rect.size.height -= kOFFSET_FOR_KEYBOARD;
 }
 self.view.frame = rect;
 
 [UIView commitAnimations];
 }
 
 
 - (void)viewWillAppear:(BOOL)animated
 {
 [super viewWillAppear:animated];
 // register for keyboard notifications
 [[NSNotificationCenter defaultCenter] addObserver:self
 selector:@selector(keyboardWillShow)
 name:UIKeyboardWillShowNotification
 object:nil];
 
 [[NSNotificationCenter defaultCenter] addObserver:self
 selector:@selector(keyboardWillHide)
 name:UIKeyboardWillHideNotification
 object:nil];
 }
 
 - (void)viewWillDisappear:(BOOL)animated
 {
 [super viewWillDisappear:animated];
 // unregister for keyboard notifications while not visible.
 [[NSNotificationCenter defaultCenter] removeObserver:self
 name:UIKeyboardWillShowNotification
 object:nil];
 
 [[NSNotificationCenter defaultCenter] removeObserver:self
 name:UIKeyboardWillHideNotification
 object:nil];
 }@end
 
 @implementation keyboard
 
 - (void)viewDidLoad {
 [super viewDidLoad];
 // Do view setup here.
 }
 
 @end */

@end

@end
